package pacman.entries.pacman;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import pacman.Executor;
import pacman.controllers.Controller;
import pacman.game.Constants;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/*

 * This is the class you need to modify for your entry. In particular, you need to

 * fill in the getAction() method. Any additional classes you write should either

 * be placed in this package or sub-packages (e.g., game.entries.pacman.mypackage).

 */


public class MyPacMan extends Controller < MOVE >
{
	public int prob = 100;
	private MOVE myMove = MOVE.NEUTRAL;
	private int limit = 100;

	public MOVE getMove(Game game, long timeDue) {

		myMove = qLearning(game, timeDue, 0.9);
		int current = game.getPacmanCurrentNodeIndex();
		for(GHOST ghost : GHOST.values())
			if(game.getGhostEdibleTime(ghost)==0 && game.getGhostLairTime(ghost)==0)
				if(game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost))<5)
					return game.getNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(ghost),DM.PATH);
		
		return myMove;
	}

	public MOVE random(Game game, long time) {

		MOVE[] moves = game.getPossibleMoves(game.getPacmanCurrentNodeIndex(), game.getPacmanLastMoveMade());
		MOVE move = moves[new Random().nextInt(moves.length)];
		System.out.println(move);
		return move;

	}



	public double qLearnRecurse(Game game, long time, int depth, int limit, double rate) {

		double best = 0;

		if (depth == limit) {
			
			best = Math.pow(rate, depth) * (2 * game.getScore() + getMoveRony(game, time)); //to insert rony's code here
			return best;
		}

		if (game.getNumberOfActivePills() + game.getNumberOfActivePowerPills() == 0) {
			
			best = (int) Math.pow(rate, depth) * (2 * game.getScore() + getMoveRony(game, time)); //to insert rony's code here
			return best;
		}

		if (game.getPacmanNumberOfLivesRemaining() == 0) {
			best = -999;
		}

		for (MOVE m: game.getPossibleMoves(game.getPacmanCurrentNodeIndex(), game.getPacmanLastMoveMade())) {

			Game g = game.copy();
			g.advanceGame(m, Executor.ghost.getMove(g, time));
			double result = qLearnRecurse(g, time, depth + 1, limit, rate);
			
			if (result > best) {
				best = result;
			}
		}
		return best;
	}

	public double getMoveRony(Game game, long timeDue) {
		
		double distanceToNearestNonEdibleGhost = getClosestNonEdibleGhostDistance(game);
		double distanceToNearestEdibleGhost = getClosestEdibleGhostDistance(game);
		double distanceToPills = getClosestPillDistance(game);
		//double result = 2 * distanceToNearestNonEdibleGhost + (1 / distanceToNearestEdibleGhost) * 10 + (1 / distanceToPills) * 10;
		double result = distanceToNearestNonEdibleGhost/(distanceToNearestEdibleGhost*distanceToPills);
		return result;

	}



	public double getClosestNonEdibleGhostDistance(Game game) {

		double distanceToNearestNonEdibleGhost = 1000;
		int current = game.getPacmanCurrentNodeIndex();
		
		for (GHOST ghost: GHOST.values())
			if (game.getShortestPathDistance(current, game.getGhostCurrentNodeIndex(ghost)) > -1 && game.getShortestPathDistance(current, game.getGhostCurrentNodeIndex(ghost)) < distanceToNearestNonEdibleGhost)
				distanceToNearestNonEdibleGhost = game.getShortestPathDistance(current, game.getGhostCurrentNodeIndex(ghost));
		return distanceToNearestNonEdibleGhost;
	}



	public double getClosestEdibleGhostDistance(Game game) {

		int current = game.getPacmanCurrentNodeIndex();
		double distanceToNearestEdibleGhost = 0;
		int minDistance = 1000;

		for (GHOST ghost: GHOST.values())
			if (game.getGhostEdibleTime(ghost) > 0) {
				int distance = game.getShortestPathDistance(current, game.getGhostCurrentNodeIndex(ghost));
				if (distance < minDistance)
					minDistance = distance;
			}

		distanceToNearestEdibleGhost = minDistance;
		return distanceToNearestEdibleGhost;

	}
	
	public double getClosestPillDistance(Game game) {
		
		double distanceToPills = 0;
		int current = game.getPacmanCurrentNodeIndex();
		int[] pills = game.getPillIndices();
		int[] powerPills = game.getPowerPillIndices();
		ArrayList < Integer > targets = new ArrayList < Integer > ();

		for (int i = 0; i < pills.length; i++)
			if (game.isPillStillAvailable(i))
				targets.add(pills[i]);

		for (int i = 0; i < powerPills.length; i++)
			if (game.isPowerPillStillAvailable(i))
				targets.add(powerPills[i]);

		int[] targetsArray = new int[targets.size()];

		for (int i = 0; i < targetsArray.length; i++)
			targetsArray[i] = targets.get(i);

		distanceToPills = getClosestNodeIndexFromNodeIndexDistance(game, current, targetsArray, DM.PATH);
		return distanceToPills;
	}

	public double getClosestNodeIndexFromNodeIndexDistance(Game game, int fromNodeIndex, int[] targetNodeIndices, DM distanceMeasure) {

		double minDistance = Integer.MAX_VALUE;
		for (int i = 0; i < targetNodeIndices.length; i++) {
			double distance = 0;
			distance = game.getDistance(targetNodeIndices[i], fromNodeIndex, distanceMeasure);
			if (distance < minDistance)
				minDistance = distance;
		}
		return minDistance;
	}
	
	public MOVE qLearning(Game game, long time, double rate) {
		double best = 0;
		MOVE bestMove = MOVE.NEUTRAL;
		int depth = 0;

		for (MOVE m: game.getPossibleMoves(game.getPacmanCurrentNodeIndex(), game.getPacmanLastMoveMade())) {
			Game g = game.copy();
			g.advanceGame(m, Executor.ghost.getMove(g, time));
			double value = qLearnRecurse(g, time, depth, 100, 0.9);
			if (value > best) {
				best = value;
				bestMove = m;
			}
		}
		limit++;
		return bestMove;
	}
}